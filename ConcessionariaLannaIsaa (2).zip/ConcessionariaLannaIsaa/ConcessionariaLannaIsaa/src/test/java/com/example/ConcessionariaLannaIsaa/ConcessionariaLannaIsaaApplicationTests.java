package com.example.ConcessionariaLannaIsaa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConcessionariaLannaIsaaApplicationTests {

	@Test
	void contextLoads() {
	}

}
