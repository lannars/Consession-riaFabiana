package com.example.ConcessionariaLannaIsaa.repository;

import com.example.ConcessionariaLannaIsaa.model.Carro;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.List;

public interface CarroRepository extends JpaRepository<Carro, Long>, JpaSpecificationExecutor<Carro> {
    List<Carro> findByMarcaContainingIgnoreCase(String marca);
    List<Carro> findByModeloContainingIgnoreCase(String modelo);
    List<Carro> findByValorBetween(Double valorMin, Double valorMax);
}
