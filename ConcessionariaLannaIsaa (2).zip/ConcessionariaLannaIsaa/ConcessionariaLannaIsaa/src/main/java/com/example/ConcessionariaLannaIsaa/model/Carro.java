package com.example.ConcessionariaLannaIsaa.model;


import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Entity
@Data
public class Carro {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String marca;
    private String modelo;
    private Integer ano;
    private String cor;
    private Double quilometragem;
    private Double valor;
    private String descricao;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    private List<ImagemCarro> imagens;


    @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
    private VideoCarro video;
}
