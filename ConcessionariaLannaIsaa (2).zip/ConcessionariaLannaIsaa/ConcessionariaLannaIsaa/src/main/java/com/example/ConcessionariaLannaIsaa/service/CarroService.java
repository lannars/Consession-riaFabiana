package com.example.ConcessionariaLannaIsaa.service;

import com.example.ConcessionariaLannaIsaa.model.Carro;
import com.example.ConcessionariaLannaIsaa.model.ImagemCarro;
import com.example.ConcessionariaLannaIsaa.repository.CarroRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class CarroService {

    @Autowired
    private CarroRepository carroRepository;

    public List<Carro> listarTodos(){
        return carroRepository.findAll();
    }

    public Optional<Carro> buscarPorId(Long id) {
        return carroRepository.findById(id);
    }

    public Carro salvar(Carro carro) {
        return carroRepository.save(carro);
    }  public void deletar(Long id) {
        carroRepository.deleteById(id);
    }

    public List<Carro> filtrar(String marca, String modelo, Double valorMin, Double valorMax) {
        return carroRepository.findAll((Specification<Carro>) (root, query, criteriaBuilder) -> {
            List<Predicate> predicates = new ArrayList<>();

            if (StringUtils.hasText(marca)) {
                predicates.add(criteriaBuilder.like(criteriaBuilder.lower(root.get("marca")), "%" + marca.toLowerCase() + "%"));
            }

            if (StringUtils.hasText(modelo)) {
                predicates.add(criteriaBuilder.like(criteriaBuilder.lower(root.get("modelo")), "%" + modelo.toLowerCase() + "%"));
            }

            if (valorMin != null) {
                predicates.add(criteriaBuilder.greaterThanOrEqualTo(root.get("valor"), valorMin));
            }

            if (valorMax != null) {
                predicates.add(criteriaBuilder.lessThanOrEqualTo(root.get("valor"), valorMax));
            }

            return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
        });
    }

    public void adicionarImagem(Carro carro, MultipartFile file) throws IOException {
        ImagemCarro imagem = new ImagemCarro();
        imagem.setNomeArquivo(file.getOriginalFilename());
        imagem.setTipoArquivo(file.getContentType());
        imagem.setDados(file.getBytes());

        if (carro.getImagens() == null) {
            carro.setImagens(new ArrayList<>());
        }
        carro.getImagens().add(imagem);
    }

    public void definirVideo(Carro carro, MultipartFile file) throws IOException {
        if (file != null && !file.isEmpty()) {
            VideoCarro video = new VideoCarro();
            video.setNomeArquivo(file.getOriginalFilename());
            video.setTipoArquivo(file.getContentType());
            video.setDados(file.getBytes());
            carro.setVideo(video);
        }
    }
}
